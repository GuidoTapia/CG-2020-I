#pragma once
#define ROOT_DIR "D:/UCSP 2020/Compu Grafica/OpenGLRoot/Practica1/"
